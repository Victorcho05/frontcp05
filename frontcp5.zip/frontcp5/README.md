Enzo Vieira Bernardini = RM563000
Liana Lyumi Morisita Fujisima = RM565698
Victor William Hwan Cho = RM565382