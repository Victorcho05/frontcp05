import hospital from "../../assets/img/hospital-clinicas.jpg";

export default function Home(){
    return(
        <div>
            <h1 className="text-3xl font-bold text-center m-6 text-emerald-700">Bem vindo ao Hospital das Clínicas</h1>

            <p className="text-1xl text-center m-6 text-slate-700"> O Hospital das Clínicas é referência em cuidado de saúde, oferecendo atendimento humanizado e tecnologia de ponta para garantir o bem-estar de todos os pacientes.</p>

            <img src={hospital} alt="Imagem Hospital" className="mx-auto rounded m-8 max-w-2xl"/>

            <h2 className="text-3xl font-bold m-4 text-center text-emerald-700">Novo modelo de consultas online</h2>
                
            <p className="text-1xl text-slate-700 m-4 text-center">Agora o Hospital das Clínicas oferece consultas online em diversas especialidades, proporcionando aos pacientes uma experiência prática, segura e personalizada. Esse novo modelo de atendimento não apenas oferece mais comodidade e reduz deslocamentos, como também permite um acompanhamento contínuo da saúde, com acesso facilitado a exames, resultados e orientações médicas. Além disso, garante a qualidade do atendimento tradicional, com profissionais qualificados, tecnologia moderna e suporte dedicado, permitindo que cada paciente receba cuidado integral no conforto e na segurança de sua casa.</p>
        </div>
    )
}