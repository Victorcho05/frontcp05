import { Link } from 'react-router-dom';

export default function Menu(){
    return(
        <nav className="menu text-2xl text-slate-100 items-center justify-center flex space-x-8 font-semibold bg-emerald-600">
            <Link to={'/'} className='m-2 hover:text-gray-300'>Home</Link>
            <Link to={'/funcionario'} className='m-2 hover:text-gray-300'>Lista Funcionários</Link>
        </nav>
    )
}