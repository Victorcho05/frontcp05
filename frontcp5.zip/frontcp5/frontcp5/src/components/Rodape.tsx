export default function Rodape(){
    return(
       <footer>
            <p className="text-1xl text-slate-300 bg-emerald-800 text-center font-bold p-2">SÃO PAULO - SP</p>
       </footer> 
    )
}