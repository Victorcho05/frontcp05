
export default function Home(){
    return(
        <div>
            <h1>Bem-vindo ao site oficial Hospital voltado para funcionários!</h1>
        </div>
    )
}

