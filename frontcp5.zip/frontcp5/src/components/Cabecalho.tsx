export default function Cabecalho(){
    return(
        <header>
            <h1 className="text-5xl text-slate-300 bg-emerald-800 text-center font-bold p-6">Funcionários Hospital</h1>
        </header>
    )
}