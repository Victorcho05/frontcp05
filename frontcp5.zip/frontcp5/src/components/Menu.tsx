import { Link } from 'react-router-dom';

export default function Menu(){
    return(
        <nav className="menu text-2xl text-slate-300 text-center flex space-x-8 font-semibold bg-emerald-600">
            <Link to={'/'} className='m-2'>Home</Link>
            <Link to={'/funcionario'} className='m-2'>Lista Funcionários</Link>
        </nav>
    )
}